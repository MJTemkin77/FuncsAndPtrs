#include "pch.h"
#include "CppUnitTest.h"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace ConsPointersFuncsTests
{
	TEST_CLASS(ConsPointersFuncsTests)
	{
	public:
		
		TEST_METHOD(TestMethod1)
		{
		}
	};
}
