// ConsPointersFunctions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include "FunctionExercises.h"
#include "PointersExercises.h"

#include "ConsPointersFunctions.h"

using namespace std;



int main()
{
    std::cout << "Hello World!\n";

    

    int a = 3, b = 12;
    ExchangeValues(a, b);
    cout << "Before the Exchange of a and b: a is now " << a << " and b is now " << b << endl;

    cout << "After the Exchange of a and b: a is now " << a << " and b is now " << b << endl;
    cout << endl;

    int nums[] = {10, 20, 30, 40, 50, 60, 70};
    int lenOfNums =
        FindArrayLenInts(&nums[0], &nums[6]);

    cout << "The number of elements in the nums array is " << lenOfNums << endl;
  


}


void FunctionExercises()
{
    // Function exercises

    //1. Return sum of parameters
    int a = 3, b = 12;
    int sum = Sum(a, b);
    cout << "Sum of " << a << " and " << b << " = " << sum << endl;
    cout << endl;

    //2. Swap reference parameters
    cout << "Before the Swap of a and b: a is now " << a << " and b is now " << b << endl;
    Swap(a, b);
    cout << "After the Swap of a and b: a is now " << a << " and b is now " << b << endl;
    cout << endl;

    //3. Overloaded examples
    double prices[] = { 7.5, 10.50, 21, 3.25, 51 };
    cout << "The total of ";
    int len = sizeof(prices) / sizeof(double);
    for (size_t i = 0; i < len; i++)
    {
        cout << prices[i] << ",";
    }
    cout << " is: " << SumItems(prices, len) << endl;
    cout << endl;

    double discount = .1;
    double threshold = 25;
    cout << "The total of ";
    for (size_t i = 0; i < len; i++)
    {
        cout << prices[i] << ",";
    }
    cout << " with a discount of " << discount <<
        " with credit is: " << SumItems(prices, len, discount) << endl << " and ";


    cout << " is double the discount: " << SumItems(prices, len, discount, true) << " when paid by cash or debit " << endl;
    cout << endl;

    //4. Recursive - PowerOf
    a = 5, b = 3;
    int pow = PowerOf(a, b);
    cout << a << " to the power of " << b << " = " << pow << endl;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
