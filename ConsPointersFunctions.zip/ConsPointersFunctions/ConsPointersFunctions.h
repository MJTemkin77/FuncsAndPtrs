#pragma once

void FunctionExercises();
